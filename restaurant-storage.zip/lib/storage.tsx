"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"

export interface StorageItem {
  id: string
  name: string
  category: "produce" | "meat" | "dairy" | "dry-goods" | "frozen" | "beverages"
  quantity: number
  unit: "lbs" | "kg" | "pieces" | "gallons" | "liters" | "boxes" | "cases"
  location: string
  addedBy: string
  addedAt: string
  lastUpdated: string
}

export interface ActivityLog {
  id: string
  action: "added" | "updated" | "removed" | "moved"
  itemName: string
  details: string
  employeeName: string
  timestamp: string
}

interface StorageContextType {
  items: StorageItem[]
  activities: ActivityLog[]
  addItem: (item: Omit<StorageItem, "id" | "addedAt" | "lastUpdated">) => void
  updateItem: (id: string, updates: Partial<StorageItem>) => void
  removeItem: (id: string) => void
  addActivity: (activity: Omit<ActivityLog, "id" | "timestamp">) => void
  increaseQuantity: (id: string, amount: number, employeeName: string) => void
  decreaseQuantity: (id: string, amount: number, employeeName: string) => void
}

const StorageContext = createContext<StorageContextType | undefined>(undefined)

// Mock storage data
const mockItems: StorageItem[] = [
  {
    id: "1",
    name: "Fresh Tomatoes",
    category: "produce",
    quantity: 25,
    unit: "lbs",
    location: "Walk-in Cooler A",
    addedBy: "Jane Employee",
    addedAt: "2025-01-05T10:30:00Z",
    lastUpdated: "2025-01-05T10:30:00Z",
  },
  {
    id: "2",
    name: "Ground Beef",
    category: "meat",
    quantity: 15,
    unit: "lbs",
    location: "Freezer B",
    addedBy: "John Manager",
    addedAt: "2025-01-04T14:20:00Z",
    lastUpdated: "2025-01-04T14:20:00Z",
  },
  {
    id: "3",
    name: "Whole Milk",
    category: "dairy",
    quantity: 8,
    unit: "gallons",
    location: "Walk-in Cooler A",
    addedBy: "Jane Employee",
    addedAt: "2025-01-03T09:15:00Z",
    lastUpdated: "2025-01-03T09:15:00Z",
  },
]

const mockActivities: ActivityLog[] = [
  {
    id: "1",
    action: "added",
    itemName: "Fresh Tomatoes",
    details: "Added 25 lbs to Walk-in Cooler A",
    employeeName: "Jane Employee",
    timestamp: "2025-01-05T10:30:00Z",
  },
  {
    id: "2",
    action: "updated",
    itemName: "Ground Beef",
    details: "Updated quantity from 20 lbs to 15 lbs",
    employeeName: "John Manager",
    timestamp: "2025-01-04T16:45:00Z",
  },
]

export function StorageProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<StorageItem[]>([])
  const [activities, setActivities] = useState<ActivityLog[]>([])

  useEffect(() => {
    const storedItems = localStorage.getItem("restaurant-storage-items")
    const storedActivities = localStorage.getItem("restaurant-storage-activities")

    if (storedItems) {
      setItems(JSON.parse(storedItems))
    } else {
      setItems(mockItems)
      localStorage.setItem("restaurant-storage-items", JSON.stringify(mockItems))
    }

    if (storedActivities) {
      setActivities(JSON.parse(storedActivities))
    } else {
      setActivities(mockActivities)
      localStorage.setItem("restaurant-storage-activities", JSON.stringify(mockActivities))
    }
  }, [])

  const addItem = (newItem: Omit<StorageItem, "id" | "addedAt" | "lastUpdated">) => {
    const item: StorageItem = {
      ...newItem,
      id: Date.now().toString(),
      addedAt: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
    }
    const updatedItems = [...items, item]
    setItems(updatedItems)
    localStorage.setItem("restaurant-storage-items", JSON.stringify(updatedItems))

    addActivity({
      action: "added",
      itemName: item.name,
      details: `Added ${item.quantity} ${item.unit} to ${item.location}`,
      employeeName: newItem.addedBy,
    })
  }

  const updateItem = (id: string, updates: Partial<StorageItem>) => {
    const updatedItems = items.map((item) =>
      item.id === id ? { ...item, ...updates, lastUpdated: new Date().toISOString() } : item,
    )
    setItems(updatedItems)
    localStorage.setItem("restaurant-storage-items", JSON.stringify(updatedItems))

    const item = items.find((i) => i.id === id)
    if (item) {
      addActivity({
        action: "updated",
        itemName: item.name,
        details: `Updated item details`,
        employeeName: updates.addedBy || "Unknown",
      })
    }
  }

  const removeItem = (id: string) => {
    const item = items.find((i) => i.id === id)
    const updatedItems = items.filter((item) => item.id !== id)
    setItems(updatedItems)
    localStorage.setItem("restaurant-storage-items", JSON.stringify(updatedItems))

    if (item) {
      addActivity({
        action: "removed",
        itemName: item.name,
        details: `Removed ${item.quantity} ${item.unit} from ${item.location}`,
        employeeName: "Current User",
      })
    }
  }

  const addActivity = (newActivity: Omit<ActivityLog, "id" | "timestamp">) => {
    const activity: ActivityLog = {
      ...newActivity,
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
    }
    const updatedActivities = [activity, ...activities]
    setActivities(updatedActivities)
    localStorage.setItem("restaurant-storage-activities", JSON.stringify(updatedActivities))
  }

  const increaseQuantity = (id: string, amount: number, employeeName: string) => {
    const item = items.find((i) => i.id === id)
    if (!item) return

    const updatedItems = items.map((item) =>
      item.id === id ? { ...item, quantity: item.quantity + amount, lastUpdated: new Date().toISOString() } : item,
    )
    setItems(updatedItems)
    localStorage.setItem("restaurant-storage-items", JSON.stringify(updatedItems))

    addActivity({
      action: "updated",
      itemName: item.name,
      details: `Added ${amount} ${item.unit} (New total: ${item.quantity + amount} ${item.unit})`,
      employeeName,
    })
  }

  const decreaseQuantity = (id: string, amount: number, employeeName: string) => {
    const item = items.find((i) => i.id === id)
    if (!item) return

    const newQuantity = Math.max(0, item.quantity - amount)
    const updatedItems = items.map((item) =>
      item.id === id ? { ...item, quantity: newQuantity, lastUpdated: new Date().toISOString() } : item,
    )
    setItems(updatedItems)
    localStorage.setItem("restaurant-storage-items", JSON.stringify(updatedItems))

    addActivity({
      action: "updated",
      itemName: item.name,
      details: `Removed ${amount} ${item.unit} (New total: ${newQuantity} ${item.unit})`,
      employeeName,
    })
  }

  return (
    <StorageContext.Provider
      value={{
        items,
        activities,
        addItem,
        updateItem,
        removeItem,
        addActivity,
        increaseQuantity,
        decreaseQuantity,
      }}
    >
      {children}
    </StorageContext.Provider>
  )
}

export function useStorage() {
  const context = useContext(StorageContext)
  if (context === undefined) {
    throw new Error("useStorage must be used within a StorageProvider")
  }
  return context
}
